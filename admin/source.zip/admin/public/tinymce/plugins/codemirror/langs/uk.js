tinymce.addI18n('uk',{
  'HTML source code': 'Вихідний код HTML',
  'Start search': 'Пошук',
  'Find next': 'Знайти наступне',
  'Find previous': 'Знайти попереднє',
  'Replace': 'Замінити',
  'Replace all': 'Замінити все'
});