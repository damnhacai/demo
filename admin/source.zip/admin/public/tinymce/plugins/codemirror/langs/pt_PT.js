tinymce.addI18n('pt_PT',{
	'HTML source code': 'Código Fonte HTML',
	'Start search': 'Iniciar Pesquisa',
	'Find next': 'Encontrar Próximo',
	'Find previous': 'Encontrar Anterior',
	'Replace': 'Substituir',
	'Replace all': 'Substituir all'
});
