<?php include 'header.php' ?>

<!-- section-element-area-start -->
<div class="section-element-area ptb-70">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="entry-header text-center mb-20">
							<img src="public/img/3.jpg" alt="not-found-img" />
							<p>Lỗi, bạn vui lòng quay lại trang.</p>
						</div>
						<div class="entry-content text-center mb-30">
							<p>Vui lòng quay lại trang.</p>
							<a href="index.php">Quay lại</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- section-element-area-end -->
<?php include 'footer.php' ?>